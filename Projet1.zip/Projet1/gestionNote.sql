-- Active: 1683654685914@@127.0.0.1@3306@gestionNote
CREATE DATABASE IF NOT EXISTS gestionNote;
use gestionNote;

CREATE TABLE eleve(
    id_eleve INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(70),
    prenom VARCHAR(70),
    sexe enum('Garçon','Fille'),
    niveau INT,
    classe INT,
    date_naissance DATE,
    numero INT

);
CREATE TABLE annee(
    libelle VARCHAR(15),
    statut ENUM ('En_cours','Terminée')
);
SELECT *FROM annee;
INSERT INTO annee (libelle,statut) VALUES('2009-2010','Terminée');


select * from eleve;
TRUNCATE eleve
;
DROP TABLE eleve;
