<?php
 
 class AjoutEleveModel{
   private $pdo;

   public function __construct(){
      $this->pdo =  new PDO("mysql:dbhost=localhost;dbname=gestionNote","root","Reg@rder20");
   }

   public function getAllEleve()
   {
      $requete= "SELECT *FROM eleve";
      $statement=$this->pdo->prepare($requete);
      $statement->execute();

      return $statement->fetchAll();
   } 
   
   public function ajouterEleve($id,$eleve)
   {
      $requete= "INSERT INTO eleve (nom,prenom,sexe,niveau,classe,date_naissance,numero) VALUES( :nm,)";
      $statement=$this->pdo->prepare($requete);
      $statement->bindValue(":statut", "En_cours");
      $statement->bindValue(":libelle", $eleve);
      $statement->bindValue(":statut", "En_cours");
      $statement->bindValue(":libelle", $eleve);
      $statement->bindValue(":statut", "En_cours");
      $statement->bindValue(":libelle", $eleve);
      $statement->bindValue(":statut", "En_cours");
      return $statement->execute();
   } 
    public function deleteAnnee($id)
    {
        $requete= "DELETE FROM annee WHERE id_annee =:id";
        $statement=$this->pdo->prepare($requete);
        $statement->bindValue(":id",$id );
        return $statement->execute();
    }
    public function editAnnee($id,$newVal)
    {
        $requete= "UPDATE annee SET libelle=:lib WHERE id_annee =:id";
        $statement=$this->pdo->prepare($requete);
        $statement->bindValue(":id",$id );
        $statement->bindValue(":lib",$newVal );
        return $statement->execute();
    }
}


