<?php
 
 class AnneeScolaireModel{
   private $pdo;

   public function __construct(){
      $this->pdo =  new PDO("mysql:dbhost=localhost;dbname=gestionNote","root","Reg@rder20");
   }

   public function getAllAnnee()
   {
      $requete= "SELECT *FROM annee";
      $statement=$this->pdo->prepare($requete);
      $statement->execute();

      return $statement->fetchAll();
   } 
   
   public function ajouterAnnee($annee)
   {
      $requete= "INSERT INTO annee (libelle,statut) VALUES(:libelle,:statut)";
      $statement=$this->pdo->prepare($requete);
      $statement->bindValue(":libelle", $annee);
      $statement->bindValue(":statut", "En_cours");
      return $statement->execute();
   } 
    public function deleteAnnee($id)
    {
        $requete= "DELETE FROM annee WHERE id_annee =:id";
        $statement=$this->pdo->prepare($requete);
        $statement->bindValue(":id",$id );
        return $statement->execute();
    }
    public function editAnnee($id,$newVal)
    {
        $requete= "UPDATE annee SET libelle=:lib WHERE id_annee =:id";
        $statement=$this->pdo->prepare($requete);
        $statement->bindValue(":id",$id );
        $statement->bindValue(":lib",$newVal );
        return $statement->execute();
    }
}