<?php
require_once "../models/AnneeScolaireModel.php";

class AnneeScolaireController
{
    private $anneSco;


    public function __construct()
    {
        $this->anneSco = new AnneeScolaireModel();
    }

    public function listerAnnee()
    {
        $annee = $this->anneSco->getAllAnnee();
        require_once "../views/AnneeScolaire.html.php";
    }

    public function ajouterAnnee()
    {
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $valeur = $_POST['anneeAjout'];
            if (count(explode("-", $valeur)) === 2) {
                $an1 = explode("-", $valeur)[0];
                $an2 = explode("-", $valeur)[1];

                if ($an2 - $an1 == 1) {
                    $this->anneSco->ajouterAnnee($valeur);
                    header('Location:/list');
                }
            } else {
                echo 'date invalide';
            }
        }
    }

    public function deleteAnnee()
    {

        $id = $_GET['id_annee'];
        $this->anneSco->deleteAnnee($id);
        header('Location:http://localhost:8000/list');
    }

    public function editAnnee()
    {
        
       $id = $_POST['id_annee'];
        $newVal= $_POST['edit'];
        $this->anneSco->editAnnee($id,$newVal);
        header('Location:http://localhost:8000/list'); 
    }
}