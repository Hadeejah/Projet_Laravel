<?php 
 
 class AccueilController{
    private $acc;
    public function __construct()
    {
        $this->acc= new AccueilController();
    }
    public function home()
    {
       var_dump('home');
       require_once "../views/Accueil.html.php"; 
    }
 }