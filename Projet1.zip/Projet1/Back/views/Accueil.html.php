<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<style>
    
</style>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <h2>Dashbord</h2>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="http://127.0.0.1:5500/Back/views/AjoutEleve.html">Enregistrer Eleve</a></li>
                <li><a href="#">Niveaux</a></li>
                <li><a href="#">Classes</a></li>
                <li><a href="#">Notes</a></li>
            </ul>
        </div>
        <div class="main_content">
            <div class="header">Welcome to Breukh'S Cool.</div>
        </div>

    </div>
</body>
<img src="tof accueil.jpg" alt="tof" class="img">

</html>