<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body class="body-login">
    <form>
        <img src="Breukh.png" alt="logo">
        <div>
            <h1>Se connecter</h1>

            <div class="inputs">
                <input type="email" placeholder="Number_tell" />
                <input type="password" placeholder="Mot de passe">
            </div>
            <div align="center">
                <button type="submit"><a href="http://127.0.0.1:5500/?">Se connecter</a></button>
            </div>
        </div>
    </form>
</body>

</html>