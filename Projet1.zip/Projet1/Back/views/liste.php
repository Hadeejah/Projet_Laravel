<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <div>
        <table class="table-style">
            <thead>
                <div class="title-tableau">Liste des élèves</div>
                <tr>
                    <th>NOM</th>
                    
                    <th>PRENOM</th>
                    
                    <th>CLASSE</th>
                    
                    <th>ACTIONS</th>
                </tr>
            </thead>
            <tbody>
                <tr class="nom">
                    <td>NDIAYE</td>
                    
                    <td>Aida</td>
                    
                    <td>2nd SA</td>
                    <th class="actions"><i class="fa fa-trash"></i>
                        <i class="fa fa-edit"></i>
                    </th>
                    
                </tr>
                <tr>
                    <td>KANE</td>
                    
                    <td>Rouguiyatou</td>
                    
                    <td>3emA</td>
                    <th class="actions"><i class="fa fa-trash"></i>
                        <i class="fa fa-edit"></i>
                    </th>
                </tr>
                
                <tr>
                    <td>DIOP</td>
                    
                    <td>Anta</td>
                    
                    <td>4emA</td>
                    <th class="actions"><i class="fa fa-trash"></i>
                        <i class="fa fa-edit"></i>
                    </th>
                </tr>
                <tr>
                    <td>DIOP</td>

                    <td>Fatou</td>
                    
                    <td>4emA</td>
                    <th class="actions"><i class="fa fa-trash"></i>
                        <i class="fa fa-edit"></i>
                    </th>
                </tr>
                <tr>
                    <td>KANE</td>
                    
                    <td>Seynabou</td>
                    
                    <td>6emB</td>
                    <th class="actions"><i class="fa fa-trash"></i>
                        <i class="fa fa-edit"></i>
                    </th>
                </tr>
            </tbody>
        </table>
    </div> 
</body>
</html>
  