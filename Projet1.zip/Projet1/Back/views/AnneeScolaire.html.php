<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="style1.css">
    <title>Document</title>
    <script src="annescolaire.js" defer></script>
</head>

<body class="body-elements">

    <form method="post" action="http://localhost:8000/add">
        <div class="anescolaire">Année Scolaire</div><input type="text" name="anneeAjout">
        <input type="submit" value="Ajouter" name="btn_aj">
    </form>
    <table class="table-style">
        <tbody>


            <?php foreach ($annee as $key => $value): ?>
                <tr>
                    <td>
                        <?php echo $value['libelle'] ?>
                    </td>

                    <td style="width:62%">
                        <?php echo $value['statut'] ?>
                        <a href="http://localhost:8000/delete?id_annee=<?= $value['id_annee'] ?>" class="fa fa-trash"></a>
                        <i class="fa fa-edit ico-edit" id="<?php echo $value['id_annee'] ?>"></i>
                    </td>
                </tr>
            <?php endforeach ?>

        </tbody>
    </table>
    <div class="modal ">
        <form action="http://localhost:8000/edit" method="post" class="content_modal">
            <div class="modal-header ">
                <h4 class="title" style="color: aliceblue;">Modifier Année</h4>
            </div>
            <div class="modal-body "> <input type="text" name="edit">
            </div>
            <input type="hidden" name="id_annee" id="id_annee">
            <div class="modal-footer">
                <button class="btn-modifier" type="submit">Modifier</button>
                <button class="btn-annuler" type="button">Annuler</button>
            </div>
        </form>
    </div>
    </div>
</body>


</html>