<?php

error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once "../controllers/AnneeScolaireController.php";
 require_once "../controllers/AccueilController.php"; 

$AnneeScolaireController = new AnneeScolaireController();
 $AccueilController = new AccueilController(); 

$path = explode("?", $_SERVER['REQUEST_URI'])[0];

if ($path == '/list') {
    $AnneeScolaireController->listerAnnee();
} else if ($path == '/add') {
    if (isset($_POST["anneeAjout"])) {
        $AnneeScolaireController->ajouterAnnee();
    }
} elseif ($path == '/delete') {
    $AnneeScolaireController->deleteAnnee();
} elseif ($path == '/edit') {
    $AnneeScolaireController->editAnnee();
} elseif ($path=='/') {
    $AccueilController->home();
} 