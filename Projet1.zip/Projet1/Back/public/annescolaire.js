const btn_modifier = document.querySelector('.btn-modifier')
const ico_edit =document.querySelectorAll('.ico-edit')
const modal=document.querySelector('.modal')
const content_modal=document.querySelector('.content_modal')
const btn_annuler=document.querySelector('.btn-annuler')
const id_annee=document.querySelector('#id_annee')
console.log(id_annee);

for (const icone_edit of ico_edit ) {
    
    icone_edit.addEventListener('click',() =>{
        modal.style.display="flex" 
        id_annee.value=icone_edit.id;
     })
}
btn_modifier.addEventListener('click',()=>{modal.style.display="none" })
btn_annuler.addEventListener('click',()=>{ modal.style.display="none"})


