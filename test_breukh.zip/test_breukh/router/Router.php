<?php
class Router{

    function __construct()
    {
        
        $uri = $_SERVER['REQUEST_URI'];
        echo ($uri);
        // supprimer chaine de caractére 1er et dernier
        /*   $string = 'Vive le PHP'; 
        $string = substr($string,1,-1); 
        echo $string;  */
        $link = (explode('/', $uri));
        echo $link[0];
        // pour savoir si le fichier existe
       /*  $filename = '/toto';
        if (file_exists($filename)) {
            echo "Le fichier $filename existe.";
        } else {
            echo "Le fichier $filename n'existe pas.";
        } */
    
     //$ctr c'est le chemin bi conntrolleur nek
        $ctrl='../Controller/'.ucfirst(strtolower($link[0])).'TotoController.php';
        if (file_exists($ctrl)) {
            echo "ok";
        } else {
            echo "ko";
        } 
    
        if (isset($link[0]) && $link[0]) {
         echo"controller existe";
        }else {
           $link[0]='home';
        }
        // est ce que action existe
        if (isset($link[1]) && $link[1]) {
            // creer le controller
            require_once "../$ctrl";
            $controller= ucfirst(strtolower($link[0]))."Controller" ;
        }

    }



}